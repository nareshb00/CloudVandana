<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reverse Words</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
            margin: 0;
        }
        textarea {
            width: 300px;
            height: 100px;
            resize: none;
            padding: 10px;
            box-sizing: border-box;
        }
        button {
            padding: 10px;
            cursor: pointer;
        }
    </style>
</head>
<body>

<div>
    <textarea id="inputSentence" placeholder="Enter a sentence"></textarea>
    <br>
    <button onclick="reverseWords()">Reverse Words</button>
    <br>
    <p id="output"></p>
</div>

<script>
    function reverseWords() {
        const inputSentence = document.getElementById('inputSentence').value;
        const reversedWords = inputSentence.split(' ').map(word => reverseWord(word)).join(' ');
        document.getElementById('output').innerText = reversedWords;
    }

    function reverseWord(word) {
        return word.split('').reverse().join('');
    }
</script>

</body>
</html>
