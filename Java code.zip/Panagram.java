package com.Jspyder.Java.Demo1;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

public class Panagram {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("eneter a sentence");
		String input=sc.nextLine().toLowerCase();
		
		boolean isPanagram=checkIfPanagram(input);
		System.out.println("is it a panagram "+isPanagram);
		sc.close();
		

	}
	public static boolean checkIfPanagram(String input)
	{
		Set<Character> uniqueChars=new HashSet<>();
		for(char ch:input.toCharArray()) {
			if(Character.isLetter(ch)) {
				uniqueChars.add(ch);
			}
		}
		return uniqueChars.size()==26;
	}

}
